package nachos.threads;

import nachos.machine.*;
import java.util.*;
import java.util.TreeSet;
import java.util.HashSet;
import java.util.Iterator;

/**
 * A scheduler that chooses threads based on their priorities.
 *
 * <p>
 * A priority scheduler associates a priority with each thread. The next thread
 * to be dequeued is always a thread with priority no less than any other
 * waiting thread's priority. Like a round-robin scheduler, the thread that is
 * dequeued is, among all the threads of the same (highest) priority, the
 * thread that has been waiting longest.
 *
 * <p>
 * Essentially, a priority scheduler gives access in a round-robin fassion to
 * all the highest-priority threads, and ignores all other threads. This has
 * the potential to
 * starve a thread if there's always a thread waiting with higher priority.
 *
 * <p>
 * A priority scheduler must partially solve the priority inversion problem; in
 * particular, priority must be donated through locks, and through joins.
 */
public class PriorityScheduler extends Scheduler {
    /**
     * Allocate a new priority scheduler.
     */
    public PriorityScheduler() {
    
	}
    
    /**
     * Allocate a new priority thread queue.
     *
     * @param	transferPriority	<tt>true</tt> if this queue should
     *					transfer priority from waiting threads
     *					to the owning thread.
     * @return	a new priority thread queue.
     */
    public ThreadQueue newThreadQueue(boolean transferPriority) {
	return new PriorityQueue(transferPriority);
    }

    public int getPriority(KThread thread) {
	Lib.assertTrue(Machine.interrupt().disabled());
		       
	return getThreadState(thread).getPriority();
    }

    public int getEffectivePriority(KThread thread) {
	Lib.assertTrue(Machine.interrupt().disabled());
		       
	return getThreadState(thread).getEffectivePriority();
    }

    public void setPriority(KThread thread, int priority) {
	Lib.assertTrue(Machine.interrupt().disabled());
		       
	Lib.assertTrue(priority >= priorityMinimum &&
		   priority <= priorityMaximum);
	
	getThreadState(thread).setPriority(priority);
    }

    public boolean increasePriority() {
	boolean intStatus = Machine.interrupt().disable();
		       
	KThread thread = KThread.currentThread();

	int priority = getPriority(thread);
	if (priority == priorityMaximum)
	    return false;

	setPriority(thread, priority+1);

	Machine.interrupt().restore(intStatus);
	return true;
    }

    public boolean decreasePriority() {
	boolean intStatus = Machine.interrupt().disable();
		       
	KThread thread = KThread.currentThread();

	int priority = getPriority(thread);
	if (priority == priorityMinimum)
	    return false;

	setPriority(thread, priority-1);

	Machine.interrupt().restore(intStatus);
	return true;
    }

    /**
     * The default priority for a new thread. Do not change this value.
     */
    public static final int priorityDefault = 1;
    /**
     * The minimum priority that a thread can have. Do not change this value.
     */
    public static final int priorityMinimum = 0;
    /**
     * The maximum priority that a thread can have. Do not change this value.
     */
    public static final int priorityMaximum = 7;    

    /**
     * Return the scheduling state of the specified thread.
     *
     * @param	thread	the thread whose scheduling state to return.
     * @return	the scheduling state of the specified thread.
     */
    protected ThreadState getThreadState(KThread thread) {
	if (thread.schedulingState == null)
	    thread.schedulingState = new ThreadState(thread);

	return (ThreadState) thread.schedulingState;
    }

    /**
     * A <tt>ThreadQueue</tt> that sorts threads by priority.
     */
    protected class PriorityQueue extends ThreadQueue {

		PriorityQueue(boolean transferPriority) {
			this.transferPriority = transferPriority;
		}

	public void waitForAccess(KThread thread) {
	    Lib.assertTrue(Machine.interrupt().disabled());
	    getThreadState(thread).waitForAccess(this);
	}

	public void acquire(KThread thread) {
	    Lib.assertTrue(Machine.interrupt().disabled());
	    getThreadState(thread).acquire(this);
	    
	}

	public KThread nextThread() {

	  Lib.assertTrue(Machine.interrupt().disabled());
	    
	    ThreadState picked = pickNextThread();
	
		
			int index = waits.lastIndexOf(picked);
			if(index!= -1){
			
				waits.remove(index);
				
			}
			if(picked == null){
				holder = null;
				return null;
			}
			picked.acquire(this);
			return picked.thread; 
		
	}


	/**
	 * Return the next thread that <tt>nextThread()</tt> would return,
	 * without modifying the state of this queue.
	 *
	 * @return	the next thread that <tt>nextThread()</tt> would
	 *		return.
	 */
	protected ThreadState pickNextThread() {
//	    
//

	    ThreadState maxts = null; //el threadstate mas alto por ende el nexthread
	    ThreadState tempts; //threadstate temporal
		
	    int maxp = -1;    //la maxima prioridad 
	    int tempp;   //prioridad temporal
	    
	    if(waits.isEmpty()){
	      return null;
	    }
	    for(int i = 0;i < waits.size();i++){
	      tempts = waits.get(i);
	      tempp = tempts.getEffectivePriority();
	      if(tempp > maxp){
		maxts = tempts;
		maxp = tempp;
	      }
	    }
	    if((maxts != null) && (maxts.donadores.size()>0)){
		maxts.resetPriority();
	    }
		
// implement me -----done-----
	    return maxts;
	}
	
	public void print() {
	    Lib.assertTrue(Machine.interrupt().disabled());
	    // implement me (if you want)
	}

	/**
	 * <tt>true</tt> if this queue should transfer priority from waiting
	 * threads to the owning thread.
	 */
	public boolean transferPriority;
	/** el que tiene los recursos en este momento*/
	public ThreadState holder = null;
	/**la lista de treads que esperan */
	public LinkedList<ThreadState> waits = new LinkedList<ThreadState>();
	
    }

    /**
     * The scheduling state of a thread. This should include the thread's
     * priority, its effective priority, any objects it owns, and the queue
     * it's waiting for, if any.
     *
     * @see	nachos.threads.KThread#schedulingState
     */
    protected class ThreadState {
	/**
	 * Allocate a new <tt>ThreadState</tt> object and associate it with the
	 * specified thread.
	 *
	 * @param	thread	the thread this state belongs to.
	 */
	public ThreadState(KThread thread) {
	    this.thread = thread;
	    setPriority(priorityDefault);
	}

	/**
	 * Return the priority of the associated thread.
	 *
	 * @return	the priority of the associated thread.
	 */
	public int getPriority() {
	    return priority;
	}

	/**
	 * Return the effective priority of the associated thread.
	 *
	 * @return	the effective priority of the associated thread.
	 */
	public int getEffectivePriority() {
  //done
	    return epriority;
	}

	/**
	 * Set the priority of the associated thread to the specified value.
	 *
	 * @param	priority	the new priority.
	 */
	public void setEPriority(int prio) {
	   // if (this.priority == priority){
		//	epriority = priority;
		//	return;
		//}
		//if(this.priority == 0){
		//	priority--;
		//}

	    /** sumamos las donaciones locas a la efective priority la prioridad normal se queda igual */
	   
	   this.epriority = prio;
	    
	    // implement me --- done -----
	}
	public void setPriority(int prio) {
	   // if (this.priority == priority){
		//	epriority = priority;
		//	return;
		//}
		//if(this.priority == 0){
		//	priority--;
		//}

	    /** sumamos las donaciones locas a la efective priority la prioridad normal se queda igual */
	   
	   this.priority = prio;
	   this.epriority = prio;
	    
	    // implement me --- done -----
	}
	//limpia las donaciones 
	public void resetPriority(){
		ThreadState temp;
		for(int i = 0;i < donadores.size();i++){
			temp = this.donadores.remove();
			temp.setEPriority(temp.priority);
		}
		
	}
	
	
	/**
	 * Called when <tt>waitForAccess(thread)</tt> (where <tt>thread</tt> is
	 * the associated thread) is invoked on the specified priority queue.
	 * The associated thread is therefore waiting for access to the
	 * resource guarded by <tt>waitQueue</tt>. This method is only called
	 * if the associated thread cannot immediately obtain access.
	 *
	 * @param	waitQueue	the queue that the associated thread is
	 *				now waiting on.
	 *
	 * @see	nachos.threads.ThreadQueue#waitForAccess
	 */
	public void waitForAccess(PriorityQueue waitQueue){
		waitQueue.waits.add(this);
		queue = (waitQueue);
		if((waitQueue.transferPriority)){
			if(this.getPriority()<7){
				waitQueue.holder.setEPriority(this.getPriority()+1);
				waitQueue.holder.donadores.add(this);
				
			}else{
				this.setPriority(6);
				waitQueue.holder.setEPriority(7);
				waitQueue.holder.donadores.add(this);
			}
			
		}
	 
	}

	/**
	 * Called when the associated thread has acquired access to whatever is
	 * guarded by <tt>waitQueue</tt>. This can occur either as a result of
	 * <tt>acquire(thread)</tt> being invoked on <tt>waitQueue</tt> (where
	 * <tt>thread</tt> is the associated thread), or as a result of
	 * <tt>nextThread()</tt> being invoked on <tt>waitQueue</tt>.
	 *
	 * @see	nachos.threads.ThreadQueue#acquire
	 * @see	nachos.threads.ThreadQueue#nextThread
	 */
	public void acquire(PriorityQueue waitQueue) {	

	  waitQueue.holder = this;
	}	

	/** The thread with which this object is associated. */	   
	protected KThread thread;
	/** The priority of the associated thread. */
	protected int priority = PriorityScheduler.priorityDefault;
	
	/** los que me donaron a mi*/
	protected LinkedList<ThreadState> donadores = new LinkedList<ThreadState>();

	/** donaciones locas*/
	protected int donaciones = 0;
	
	protected ThreadQueue queue;

	/** prioridad efectiva*/
	protected int epriority = PriorityScheduler.priorityDefault;
	
    }
}
